#include <stdio.h>
#include <string.h>
#include <mosquitto.h>

#define AWS_IOT_ENDPOINT "a3t4i59m684ijv-ats.iot.eu-north-1.amazonaws.com"
#define AWS_PORT 8883
#define AWS_TOPIC "myTopic"

#define ROOT_CA_PATH "/home/raspberrypi/awsiot/raspberry-pi_pull_C/certs_c/AmazonRootCA1.pem"
#define CERTIFICATE_PATH "/home/raspberrypi/awsiot/raspberry-pi_pull_C/certs_c/certificate.pem.crt"
#define PRIVATE_KEY_PATH "/home/raspberrypi/awsiot/raspberry-pi_pull_C/certs_c/private.pem.key"

#define PAYLOAD "{\"Temperature\":\"37\"}"

int main()
{
    struct mosquitto *mosq = NULL;
    int rc = 0;

    mosquitto_lib_init();

    mosq = mosquitto_new(NULL, true, NULL);
    if (!mosq) {
        fprintf(stderr, "Error: Out of memory.\n");
        return 1;
    }

    rc = mosquitto_tls_set(mosq, ROOT_CA_PATH, NULL, CERTIFICATE_PATH, PRIVATE_KEY_PATH, NULL);
    if (rc != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Error: Unable to set TLS options: %s.\n", mosquitto_strerror(rc));
        return 1;
    }

    rc = mosquitto_connect(mosq, AWS_IOT_ENDPOINT, AWS_PORT, 60);
    if (rc != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Error: Unable to connect to AWS IoT MQTT broker: %s.\n", mosquitto_strerror(rc));
        return 1;
    }

    // Publish the payload to the subscribed topic
    rc = mosquitto_publish(mosq, NULL, AWS_TOPIC, strlen(PAYLOAD), PAYLOAD, 0, false);
    if (rc != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Error: Unable to publish message: %s.\n", mosquitto_strerror(rc));
        return 1;
    }

    mosquitto_loop_forever(mosq, -1, 1);

    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();
    
    return 0;
}
